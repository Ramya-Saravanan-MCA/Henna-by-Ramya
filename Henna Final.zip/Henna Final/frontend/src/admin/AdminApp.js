import React, { useState } from 'react';
import { LayoutDashboard, BookOpenCheck } from 'lucide-react';
import Dashboard from './Dashboard';
import BookingsPage from './Orders';

const AdminApp = () => {
  const [activePage, setActivePage] = useState('dashboard');

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'bookings':
        return <BookingsPage />;
      default:
        return <Dashboard />;
    }
  };

  const navButton = (page, Icon, label) => (
    <button
      onClick={() => setActivePage(page)}
      className={`flex items-center w-full text-left px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-150 ${
        activePage === page
          ? 'bg-purple-100 text-plum font-semibold shadow'
          : 'text-gray-600 hover:bg-purple-50 hover:text-plum'
      }`}
    >
      <Icon className="w-5 h-5 mr-2" />
      {label}
    </button>
  );

  return (
    <div className="min-h-screen flex bg-gray-50 font-poppins">
      <aside className="w-64 bg-white shadow-md border-r px-6 py-8">
        <h1 className="text-2xl font-bold text-plum mb-8 text-center">Admin Panel</h1>
        <nav className="space-y-4">
          {navButton('dashboard', LayoutDashboard, 'Dashboard')}
          {navButton('bookings', BookOpenCheck, 'Bookings')}
        </nav>
      </aside>

      <main className="flex-1 p-10 bg-gray-100 overflow-y-auto">{renderContent()}</main>
    </div>
  );
};

export default AdminApp;
