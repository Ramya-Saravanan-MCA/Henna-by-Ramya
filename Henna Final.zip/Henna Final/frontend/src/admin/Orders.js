import React, { useEffect, useState } from 'react';

const Orders = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('http://localhost:5000/admin/bookings')
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch bookings');
        return res.json();
      })
      .then((data) => {
        console.log("Bookings fetched:", data);
        setBookings(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching bookings:', err);
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-md p-8">
        <h2 className="text-3xl font-semibold mb-6 text-plum border-b pb-3">
          All Bookings
        </h2>

        {loading ? (
          <p className="text-gray-500">Loading bookings...</p>
        ) : error ? (
          <p className="text-red-500 font-semibold">Error: {error}</p>
        ) : bookings.length === 0 ? (
          <p className="text-gray-600">No bookings found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm text-left border">
              <thead className="bg-plum text-white">
                <tr>
                  <th className="px-5 py-3">Name</th>
                  <th className="px-5 py-3">Email</th>
                  <th className="px-5 py-3">Phone</th>
                  <th className="px-5 py-3">Date</th>
                  <th className="px-5 py-3">Service</th>
                  <th className="px-5 py-3">Location</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {bookings.map((booking, index) => (
                  <tr key={index} className="transition">
                    <td className="px-5 py-3">{booking.name}</td>
                    <td className="px-5 py-3 truncate max-w-xs">{booking.email}</td>
                    <td className="px-5 py-3">{booking.phone}</td>
                    <td className="px-5 py-3">{booking.date}</td>
                    <td className="px-5 py-3 capitalize">{booking.serviceType}</td>
                    <td className="px-5 py-3">{booking.location}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;
