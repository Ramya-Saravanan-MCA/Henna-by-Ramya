import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import {
  MdOutlineAnalytics, MdEventAvailable, MdOutlineGroupWork, MdEventNote,
  MdEmojiEmotions, MdOutlineSpa, MdTrendingUp, MdTrendingDown
} from 'react-icons/md';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#f97316'];

const serviceIcons = {
  bridal: <MdOutlineAnalytics className="text-2xl" />,  
  party: <MdEventAvailable className="text-2xl" />,     
  regular: <MdOutlineGroupWork className="text-2xl" />, 
  engagement: <MdEventNote className="text-2xl" />,     
  babyshower: <MdEmojiEmotions className="text-2xl" />, 
  mehndi: <MdOutlineSpa className="text-2xl" />,        
  default: <MdOutlineAnalytics className="text-2xl" />
};

const Dashboard = () => {
  const [summary, setSummary] = useState({ totalBookings: 0, serviceCounts: [] });
  const [monthlyStats, setMonthlyStats] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admin/summary').then(res => setSummary(res.data));
    axios.get('http://localhost:5000/admin/monthly-stats').then(res => setMonthlyStats(res.data));
  }, []);

  const lastMonth = monthlyStats[monthlyStats.length - 2]?.count || 0;
  const currentMonth = monthlyStats[monthlyStats.length - 1]?.count || 0;
  const trend = currentMonth - lastMonth;

  return (
    <div className="p-10 bg-gradient-to-br from-white to-gray-100 min-h-screen text-[#1f2937] space-y-10 transition-transform duration-300 ease-in-out scale-[0.98] hover:scale-100">
      <div className="border-b pb-4">
        <h1 className="text-4xl font-extrabold tracking-tight">Welcome, Ramya</h1>
        <p className="text-sm text-gray-500 mt-1">Track your bookings and stats</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border rounded-2xl p-6 shadow-md hover:shadow-lg transition-shadow flex items-center gap-4">
          <div className="p-3 rounded-full bg-blue-100 text-blue-600 text-2xl">
            <MdOutlineAnalytics />
          </div>
          <div>
            <p className="text-sm text-gray-500">Total Bookings</p>
            <h2 className="text-3xl font-bold text-blue-700">{summary.totalBookings}</h2>
            <span className={`text-sm flex items-center gap-1 mt-1 ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {trend >= 0 ? <MdTrendingUp /> : <MdTrendingDown />} {Math.abs(trend)} from last month
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {summary.serviceCounts.map((item, i) => {
          const icon = serviceIcons[item._id?.toLowerCase()] || serviceIcons.default;
          const color = COLORS[i % COLORS.length];

          return (
            <div key={i} className="bg-white border rounded-2xl p-6 shadow-md hover:shadow-lg transition-transform transform hover:scale-105 flex items-center gap-4">
              <div className="p-3 rounded-full text-white text-2xl" style={{ backgroundColor: color }}>
                {icon}
              </div>
              <div>
                <p className="text-sm text-gray-500 capitalize">{item._id}</p>
                <h2 className="text-2xl font-bold" style={{ color }}>{item.count}</h2>
              </div>
            </div>
          );
        })}
      </div>

      <div className="border rounded-2xl p-6 shadow-md hover:shadow-lg bg-white transition-transform transform hover:scale-[1.01]">
        <h3 className="text-xl font-semibold mb-4">📊 Monthly Bookings</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={monthlyStats}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="border rounded-2xl p-6 shadow-md hover:shadow-lg bg-white transition-transform transform hover:scale-[1.01]">
        <h3 className="text-xl font-semibold mb-4">🧾 Service Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={summary.serviceCounts}
              dataKey="count"
              nameKey="_id"
              cx="50%"
              cy="50%"
              outerRadius={100}
              label
            >
              {summary.serviceCounts.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Dashboard;
