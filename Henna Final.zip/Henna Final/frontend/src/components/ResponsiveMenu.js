import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';

const ResponsiveMenu = ({ isOpen }) => {
  return (
    <AnimatePresence mode="wait">
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -100 }}
          transition={{ duration: 0.3 }}
          className="absolute top-20 left-0 w-full h-screen z-20 lg:hidden"
        >
          <div className="text-xl font-semibold bg-beige text-plum py-10 m-6 rounded-3xl shadow-xl backdrop-blur-md bg-opacity-80 border border-warmtaupe/30">
            <ul className="flex flex-col justify-center items-center gap-8">

              <li className="hover:tracking-wide transition-all duration-300">
                <Link to="/">HOME</Link>
              </li>

              <li className="hover:tracking-wide transition-all duration-300">
                <Link to="/services">SERVICES</Link>
              </li>

              <li className="hover:tracking-wide transition-all duration-300">
                <Link to="/about">ABOUT US</Link>
              </li>

              <li className="hover:tracking-wide transition-all duration-300">
                <Link to="/bookings">BOOKINGS</Link>
              </li>

              <li className="hover:tracking-wide transition-all duration-300">
                <Link to="/contact">CONTACT US</Link>
              </li>

            </ul>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ResponsiveMenu;
