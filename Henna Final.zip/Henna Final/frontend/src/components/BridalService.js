import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom'; 
import bridalHero from '../assets/hero.png';
import { FaLeaf, FaStar, FaRegClock, FaPaintBrush } from 'react-icons/fa';
import Footer from './Footer';
import Navbar from './Navbar';
import CustomArrow from './CustomArrow';

const features = [
  {
    icon: <FaLeaf />,
    title: 'Natural Ingredients',
    desc: 'We use only organic henna and essential oils to ensure safety and rich color. Our blends are free from chemicals, offering a skin-friendly, aromatic experience that promotes a deeper, longer-lasting stain.'
  },
  {
    icon: <FaStar />,
    title: 'Custom Designs',
    desc: 'Tailored motifs reflect your culture, personality, and love story. From traditional Indian bridal patterns to contemporary fusion styles, we collaborate with you to create a one-of-a-kind masterpiece that’s uniquely yours.'
  },
  {
    icon: <FaRegClock />,
    title: 'Timely Service',
    desc: 'We value your time. Sessions are prompt and relaxing. Our professionals ensure a smooth process, arriving on schedule and delivering exquisite designs without compromising your event timeline.'
  },
  {
    icon: <FaPaintBrush />,
    title: 'Artistic Excellence',
    desc: 'Created by professional artists with years of bridal experience. Each design is crafted with precision, creativity, and passion, turning your hands and feet into elegant canvases of cultural celebration.'
  }
];

const faqs = [
  { q: 'How long does the bridal henna process take?', a: 'Depending on the package, it can take 2 to 6 hours. We recommend early booking for relaxed sessions.' },
  { q: 'How long will the henna last?', a: 'Stains typically last 1–2 weeks, depending on skin type and care. We provide aftercare tips for best results.' },
  { q: 'Can I get a custom design?', a: 'Absolutely! We love creating unique patterns based on your story, culture, or theme.' },
  { q: 'Is a trial session available?', a: 'Yes, trial sessions are available to ensure you love the design and placement before your big day.' },
];

const categories = [
  { title: 'Bridal Henna', image: bridalHero },
  { title: 'Floral Designs', image: bridalHero },
  { title: 'Mandala Art', image: bridalHero },
  { title: 'Party Henna', image: bridalHero },
];

const BridalService = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const toggleIndex = (index) => setOpenIndex(openIndex === index ? null : index);

  return (
    <div className="relative text-gray-900 font-poppins">
      {/* <Navbar /> */}
      <CustomArrow />

      <div className="relative h-[65vh] overflow-hidden">
        <img
          src={bridalHero}
          alt="Bridal Henna"
          className="absolute inset-0 w-full h-full object-cover scale-105"
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative z-10 flex items-center justify-center h-full px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h1 className="text-4xl md:text-6xl font-cursive font-bold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
              Personalized Henna for Your Big Day
            </h1>
            <p className="mt-4 text-lg md:text-xl text-white font-light drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]">
              Crafted with tradition, love, and artistic finesse.
            </p>
          </motion.div>
        </div>
      </div>

      <motion.section
        className="pt-16 pb-10 px-6 text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.6 }}
        variants={{ hidden: { opacity: 0, y: 40 }, visible: { opacity: 1, y: 0 } }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-black mb-10">Crafting Magic for Your Big Day</h2>
        <p className="max-w-2xl mx-auto text-lg text-gray-700 leading-relaxed">
          Every bride deserves to feel radiant. Our henna tells stories through intricate patterns designed just for you. It's not just art — it's your journey.
        </p>
        <div className="w-24 h-1 bg-warmTaupe mx-auto my-6 rounded-full" />
      </motion.section>

      <section className="pt-16 pb-10 px-6">
  <h3 className="text-3xl md:text-4xl font-bold text-center text-black mb-12">Our Henna Styles</h3>
  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 max-w-6xl mx-auto">
    {categories.map((cat, i) => (
      <motion.div
        key={i}
        whileHover={{ scale: 1.05 }}
        className="rounded-xl overflow-hidden shadow-lg text-center bg-white"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: i * 0.1 }}
        viewport={{ once: false, amount: 0.3 }}
      >
        <img src={cat.image} alt={cat.title} className="h-48 w-full object-cover" />
        <div className="py-4 pb-4">
          <Link
            to="/Gallery"
            className="inline-block bg-plum text-white px-4 py-2 rounded-full font-medium hover:bg-plum-dark transition-all duration-300"
          >
            {cat.title}
          </Link>
        </div>
      </motion.div>
    ))}
  </div>
</section>


      <section className="pt-16 pb-10 px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-black mb-12">
          Our Bridal Henna Journey
        </h2>
        <div className="max-w-3xl mx-auto relative border-l-4 border-warmTaupe space-y-14">
          {features.map((item, i) => (
            <motion.div
              key={i}
              whileInView={{ opacity: 1, x: 0 }}
              initial={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              viewport={{ once: false, amount: 0.3 }}
              className="pl-10 relative"
            >
              <div className="absolute -left-6 top-1.5 w-10 h-10 bg-warmTaupe text-white rounded-full flex items-center justify-center shadow-md">
                {item.icon}
              </div>
              <h3 className="text-xl font-semibold text-warmTaupe mb-2">{item.title}</h3>
              <p className="text-gray-700 text-base leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <motion.section
        className="pt-16 pb-10 px-6"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.5 }}
        variants={{ hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } }}
      >
        <h3 className="text-3xl md:text-4xl font-bold text-center text-black mb-12">Bridal Design Highlights</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {[...Array(6)].map((_, i) => (
            <motion.div key={i} whileHover={{ scale: 1.05 }} className="overflow-hidden rounded-xl shadow">
              <img src={bridalHero} className="h-64 w-full object-cover" alt={`Design ${i + 1}`} />
            </motion.div>
          ))}
        </div>
      </motion.section>

      <section className="pt-16 pb-10 px-6">
        <motion.h3
          className="text-3xl md:text-4xl font-bold text-center text-black mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: false, amount: 0.3 }}
        >
          Bridal Packages
        </motion.h3>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
  {[
    {
      name: 'Elegant Bridal',
      includes: [
        'Hands till elbow',
        'Feet till ankle',
        'Simple design',
      ],
      price: '₹3000',
      tag: 'Best for Simplicity',
    },
    {
      name: 'Premium Glow',
      includes: [
        'Full hands & feet',
        'Glitter work',
        'Detailed patterns',
      ],
      price: '₹4500',
      tag: 'Most Popular',
    },
    {
      name: 'Royal Signature',
      includes: [
        'Full body mehndi',
        'Trial session',
        'Custom design',
      ],
      price: '₹6500+',
      tag: 'Luxury Experience',
    },
  ].map((pkg, i) => (
    <motion.div
      key={i}
      className="cursor-pointer bg-white p-8 rounded-2xl shadow-xl border border-warmTaupe/20 relative hover:shadow-2xl hover:scale-[1.03] transition-transform duration-300"
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: i * 0.1 }}
      viewport={{ once: false, amount: 0.3 }}
      onClick={() => {
        console.log('Selected package:', pkg.name);
      }}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          console.log('Selected package (keyboard):', pkg.name);
        }
      }}
    >
      <span className="absolute top-4 right-4 bg-warmTaupe text-white text-xs font-semibold px-3 py-1 rounded-full shadow">
        {pkg.tag}
      </span>
      <h4 className="text-2xl font-bold text-warmTaupe mb-4">{pkg.name}</h4>
      <ul className="text-gray-700 list-disc list-inside space-y-1">
        {pkg.includes.map((item, idx) => (
          <li key={idx}>{item}</li>
        ))}
      </ul>
      <p className="mt-6 text-xl font-bold text-gray-900">{pkg.price}</p>
    </motion.div>
  ))}
</div>


      </section>

      <section className="pt-16 pb-6 px-6 max-w-4xl mx-auto">
        <motion.h3
          className="text-3xl md:text-4xl font-bold text-center text-black mb-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: false, amount: 0.3 }}
        >
          Frequently Asked Questions
        </motion.h3>
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              onClick={() => toggleIndex(i)}
              className="cursor-pointer border border-gray-200 rounded-xl bg-white shadow-sm"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              viewport={{ once: false, amount: 0.3 }}
            >
              <div className="flex justify-between items-center px-6 py-4">
                <h4 className="text-black text-lg font-semibold">{faq.q}</h4>
                <span className="text-2xl text-warmTaupe">{openIndex === i ? '−' : '+'}</span>
              </div>
              <AnimatePresence initial={false}>
                {openIndex === i && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.4 }}
                    className="px-6 pb-4 text-gray-800 text-sm"
                  >
                    {faq.a}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BridalService;
