import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { FaInstagram, FaWhatsapp, FaFacebookF, FaEnvelope } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Footer = () => {
  const ref = useRef(null);
  const inView = useInView(ref, {
    once: false,
    amount: 0.3,
  });

  return (
    <footer
      ref={ref}
      className="relative  text-gray-800 font-poppins pt-12 pb-8 px-6 overflow-hidden"
    >
      <div className="absolute top-0 left-0 w-full overflow-hidden leading-[0]">
        <svg className="relative block w-full h-[50px]" viewBox="0 0 1440 60" preserveAspectRatio="none">
          <path d="M0,0 C360,60 1080,0 1440,60 L1440,0 L0,0 Z" fill="#f5f1ec" />
        </svg>
      </div>

      <motion.div
        className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left z-10 relative"
        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
        transition={{ duration: 0.8 }}
      >
        <div>
          <h2 className="text-2xl font-cursive text-warmtaupe font-bold mb-2">Henna by Ramya</h2>
          <p className="text-sm text-gray-600">
            Elegant mehndi for weddings, festivals & events. Tradition meets artistry.
          </p>
        </div>

        <div>
          <h3 className="text-base font-semibold mb-2">Quick Links</h3>
          <ul className="space-y-1 text-sm text-gray-600">
            <li><Link to="/" className="hover:text-warmtaupe transition">Home</Link></li>
            <li><Link to="/services" className="hover:text-warmtaupe transition">Services</Link></li>
            <li><Link to="/bookings" className="hover:text-warmtaupe transition">Bookings</Link></li>
            <li><Link to="/contact" className="hover:text-warmtaupe transition">Contact Us</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-base font-semibold mb-2">Contact</h3>
          <p className="text-sm text-gray-600 flex items-center justify-center md:justify-start gap-2 mb-1">
            <FaEnvelope /> ramyahenna@example.com
          </p>
          <p className="text-sm text-gray-600 flex items-center justify-center md:justify-start gap-2">
            <FaWhatsapp /> +1 (234) 567-890
          </p>
          <div className="flex justify-center md:justify-start gap-3 mt-3">
            {[FaInstagram, FaWhatsapp, FaFacebookF].map((Icon, idx) => (
              <motion.a
                key={idx}
                href="#"
                whileHover={{ scale: 1.15 }}
                className="w-9 h-9 flex items-center justify-center bg-white text-gray-700 rounded-full shadow hover:bg-warmtaupe hover:text-white transition"
              >
                <Icon />
              </motion.a>
            ))}
          </div>
        </div>
      </motion.div>

      <motion.p
        animate={inView ? { opacity: 1 } : { opacity: 0 }}
        transition={{ delay: 0.4, duration: 0.4 }}
        className="text-xs text-gray-500 mt-8 text-center z-10 relative"
      >
        © {new Date().getFullYear()} Henna by Ramya — All rights reserved.
      </motion.p>
    </footer>
  );
};

export default Footer;
