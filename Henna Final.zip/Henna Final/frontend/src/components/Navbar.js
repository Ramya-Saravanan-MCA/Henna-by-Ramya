import React from 'react';
import { NavbarMenu } from '../data';
import { MdMenu } from 'react-icons/md';
import { IoMdHeart } from 'react-icons/io';
import { motion } from 'framer-motion';
import { useLocation, Link, useNavigate } from 'react-router-dom'; 
import ResponsiveMenu from './ResponsiveMenu';
import { SlideRight } from '../utility/animation';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation(); 
  const navigate = useNavigate();

  return (
    <>
      <nav>
        <motion.div
          variants={SlideRight(1.0)}
          initial="hidden"
          animate="visible"
          className="container flex justify-between items-center py-6"
        >
          {/* Left - Logo */}
          <div className="text-2xl flex items-center gap-2 font-bold">
            <IoMdHeart className="text-3xl text-plum" />
            <p>Henna by Ramya</p>
          </div>

          {/* Center - Menu */}
          <div className="hidden lg:flex gap-6 items-center">
            <ul className="flex items-center gap-6">
              {NavbarMenu.map((item) => (
                <li key={item.id} className="relative">
                  <Link
                    to={item.link}
                    className={`inline-block text-sm xl:text-base py-1 px-2 xl:px-3 font-semibold transition-all duration-300 ${
                      location.pathname === item.link
                        ? 'text-plum border-b-2 border-plum'
                        : 'text-gray-600 hover:text-plum'
                    }`}
                  >
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>

            <Link
              to="/auth"
              className="inline-block text-sm xl:text-base py-1 px-3 font-semibold text-white bg-plum rounded hover:bg-plum transition"
            >
              Login
            </Link>


          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden" onClick={() => setIsOpen(!isOpen)}>
            <MdMenu className="text-4xl" />
          </div>
        </motion.div>
      </nav>

      {/* Responsive Menu */}
      <ResponsiveMenu isOpen={isOpen} />
    </>
  );
};

export default Navbar;
