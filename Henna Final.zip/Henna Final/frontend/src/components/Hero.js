import React from 'react'
import hero from "../assets/transparent.png"
import { motion } from 'framer-motion'
import { SlideRight } from '../utility/animation'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
        const navigate = useNavigate();

  return (
    <>
        <div className='container grid grid-cols-1 md:grid-cols-2 min-h-[650px] relative'>
                <div className='flex flex-col justify-center py-14 md:pr-16 xl:pr-40 md:py-0 '>
                    <div className="text-center md:text-left space-y-6">
                        <motion.p
                        variants={SlideRight(0.4)}
                        initial="hidden"
                        animate="visible" 
                        className='text-warmTaupe uppercase font-semibold'>100% Satisfaction Guarantee</motion.p>
                      <motion.h1
                            variants={SlideRight(0.6)}
                            initial="hidden"
                            animate="visible"
                            className="text-5xl font-semibold lg:text-6xl leading-tight"
                            >
                            Meet Your{' '}
                            <span className="relative inline-block group overflow-hidden cursor-pointer">
                                <span className="relative text-plum z-10">Henna Artist</span>

                                <span
                                className="absolute inset-x-0 bottom-0 h-[10px] bg-beige z-0 transition-all duration-300 group-hover:h-full"
                                ></span>
                            </span>
                        </motion.h1>
                        <motion.p
                        variants={SlideRight(0.8)}
                        initial="hidden"
                        animate="visible"
                        >
                            I'm your perfect Henna artist, blending creativity, tradition, and precision in every design. Whether it's a bridal celebration or a festive occasion, I bring elegance and personal touch to make your moments truly unforgettable.
                        </motion.p>

                        <motion.button
                            variants={SlideRight(1.0)}
                            initial="hidden"
                            animate="visible"
                            className="primary-btn"
                            onClick={() => navigate('/about')}
                            >
                            STAY CONNECTED
                        </motion.button>
                    </div>
                </div>
            
            <div className='h-[700px] w-[700px] bg-beige/40 absolute -top-1/2 right-0 rounded-3xl rotate-45 -z-10'></div>

           <div className="flex justify-center items-center">
            <motion.div
                initial={{ opacity: 0, x: 200 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ type: "spring", stiffness: 100, delay: 0.2 }}
                className="relative w-[350px] md:w-[550px] xl:w-[700px] pb-10 clip-hero"
            >
                <img src={hero} alt="Hero" className="w-full h-auto object-cover" />
            </motion.div>
            </div>
        </div>
    </>
  )
}

export default Hero