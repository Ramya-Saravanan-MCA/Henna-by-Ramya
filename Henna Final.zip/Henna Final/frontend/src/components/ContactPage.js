import React from 'react';
import { motion } from 'framer-motion';
import Navbar from './Navbar';
import Footer from './Footer';
import CustomArrow from './CustomArrow';
import { FaPhoneAlt, FaEnvelope, FaMapMarkerAlt, FaClock } from 'react-icons/fa';
import heroImage from '../assets/hero.png';

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const ContactPage = () => {
  return (
    <div className="bg-white text-gray-900 font-poppins flex flex-col min-h-screen">
      {/* <Navbar /> */}
      <CustomArrow />

      {/* Hero Section */}
      <section
        className="h-[60vh] bg-cover bg-center flex items-center justify-center px-6 md:px-12"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white/90 p-8 rounded-xl shadow-lg text-center max-w-2xl"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Get in Touch with Ramya</h1>
          <p className="text-base md:text-lg text-gray-700 leading-relaxed">
            We're here to answer your questions, schedule appointments, and explore collaborations.
          </p>
        </motion.div>
      </section>

      <section className="py-20 px-6 md:px-20 bg-gray-50">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12">
          <motion.div
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="bg-white p-10 rounded-2xl border shadow-sm"
          >
            <h2 className="text-2xl font-semibold text-plum mb-5">Studio Address</h2>
            <p className="flex items-start text-lg text-gray-800 mb-4">
              <FaMapMarkerAlt className="text-xl mr-3 mt-1 text-plum" />
              22 Floral Street, Coimbatore, Tamil Nadu – 641001
            </p>
            <p className="text-gray-600 text-base">
              A calm, elegant space curated for every bride’s unique journey.
            </p>
          </motion.div>

          <motion.div
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="bg-white p-10 rounded-2xl border shadow-sm"
          >
            <h2 className="text-2xl font-semibold text-plum mb-5">Contact Information</h2>
            <ul className="space-y-5 text-gray-800">
              {[
                { icon: <FaPhoneAlt />, text: '+91 98765 43210' },
                { icon: <FaEnvelope />, text: 'hennabyramya@gmail.com' },
                { icon: <FaClock />, text: '10:00 AM – 8:00 PM (Open Daily)' },
              ].map(({ icon, text }, idx) => (
                <li key={idx} className="flex items-center gap-4 text-base">
                  <span className="text-xl text-plum">{icon}</span> {text}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </section>

      <section className="py-16 px-6 md:px-20 bg-white">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">What Can You Reach Out For?</h2>
          <div className="grid sm:grid-cols-2 gap-10 text-gray-700 text-base leading-relaxed">
            <p>🌿 Bridal Bookings – Reserve your date and discuss bridal themes.</p>
            <p>💃 Event Henna – Celebrate with elegance at parties, showers & more.</p>
            <p>🤝 Creative Collabs – Let’s team up! Content creators & vendors welcome.</p>
            <p>🎨 Henna Workshops – Join immersive, hands-on learning experiences.</p>
          </div>
        </div>
      </section>

     

        <div className="rounded-xl overflow-hidden shadow-md w-full h-64 md:h-80">
          <iframe
            title="Nagal Nagar, Dindigul"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3915.881730944933!2d77.9781377!3d10.3519111!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba867e2f8ee3f71%3A0xabcdef1234567890!2sNagal%20Nagar%2C%20Dindigul%2C%20Tamil%20Nadu%20624003!5e0!3m2!1sen!2sin!4v1721111111111!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>



      <Footer />
    </div>
  );
};

export default ContactPage;
