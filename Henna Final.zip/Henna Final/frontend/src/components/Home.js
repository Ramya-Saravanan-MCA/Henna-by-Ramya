import React from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import NumberCounter from '../components/NumberCounter';
import WhyChoose from '../components/WhyChoose';
import CustomArrow from '../components/CustomArrow';
import Banner from '../banner/Banner';
import Footer from '../components/Footer';
import heroimage1 from '../assets/heroimage1.jpg';

const BannerData = {
  image: heroimage1,
  tag: 'ARTISTRY THAT SPEAKS TO YOU',
  title: 'Exquisite Henna Creations',
  subtitle:
    'Experience the beauty of intricate henna designs crafted to reflect your story, style, and spirit—making every celebration unforgettable and uniquely yours.',
  link: '#',
};

const BannerData2 = {
  image: heroimage1,
  tag: 'DESIGNS AS UNIQUE AS YOU',
  title: 'Custom Henna Artistry',
  subtitle:
    'Embrace the tradition and elegance of henna with personalized designs tailored to your personality, occasion, and cultural heritage.',
  link: '#',
};


const Home = () => {
  return (
    <>
      <CustomArrow />
      {/* <Navbar /> */}
      <Hero />
      <NumberCounter />
      <WhyChoose />
      <Banner {...BannerData} />
      <Banner {...BannerData2} reverse={true} />
      <Footer />
    </>
  );
};

export default Home;
