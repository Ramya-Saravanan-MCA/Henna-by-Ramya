import React from 'react';
import headerImage from '../assets/headerImage.jpg'
import Collection2 from '../assets/Collection2.jpg'
import Collection3 from '../assets/Collection3.jpg'
import Collection4 from '../assets/Collection4.jpg'
import henna4 from '../assets/henna4.jpeg'
import henna5 from '../assets/henna5.jpeg'
import henna6 from '../assets/henna6.jpeg'
import henna7 from '../assets/henna7.jpeg'
import henna8 from '../assets/henna8.jpeg'
import henna9 from '../assets/henna9.jpeg'
import henna10 from '../assets/henna10.jpeg'


import { useNavigate } from 'react-router-dom';
const Photos = () => {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center text-center px-5 mt-10">
      <div className="w-full md:w-1/2 pb-12">
        <h3 className="text-4xl font-extrabold pb-3 border-b-4 border-gray-900">
          Bridal <span className="font-light">Collections</span>
        </h3>
      </div>

      <div className="flex flex-col md:flex-row md:justify-between gap-4 w-full">
        
        <div className="flex flex-col w-full md:w-1/3 gap-4">
          <img src={headerImage} alt="henna1" className="w-full rounded-md" />
          <img src={Collection2} alt="henna2" className="w-full rounded-md" />
          <img src={Collection3} alt="henna4" className="w-full rounded-md" />
          <img src={Collection4} alt="henna5" className="w-full rounded-md" />
          <img src={henna4} alt="henna6" className="w-full rounded-md" />
          <img src={henna5} alt="henna7" className="w-full rounded-md" />
          <img src={henna6} alt="henna8" className="w-full rounded-md" />
          <img src={henna7} alt="henna9" className="w-full rounded-md" />
          <img src={henna8} alt="henna10" className="w-full rounded-md" />
        </div>

        
        <div className="flex flex-col w-full md:w-1/3 gap-4">
          <img src={henna9} alt="henna11" className="w-full rounded-md" />
          <img src={henna10} alt="henna12" className="w-full rounded-md" />
          <img src={headerImage} alt="henna1" className="w-full rounded-md" />
          <img src={Collection2} alt="henna2" className="w-full rounded-md" />
          <img src={Collection3} alt="henna4" className="w-full rounded-md" />
          <img src={Collection4} alt="henna5" className="w-full rounded-md" />
          <img src={henna4} alt="henna6" className="w-full rounded-md" />
          <img src={henna5} alt="henna7" className="w-full rounded-md" />
          <img src={henna6} alt="henna8" className="w-full rounded-md" />
        </div>

        
        <div className="flex flex-col w-full md:w-1/3 gap-4">
        <img src={henna8} alt="henna1" className="w-full rounded-md" />
          <img src={henna7} alt="henna2" className="w-full rounded-md" />
          <img src={henna6} alt="henna4" className="w-full rounded-md" />
          <img src={henna5} alt="henna5" className="w-full rounded-md" />
          <img src={henna4} alt="henna6" className="w-full rounded-md" />
          <img src={Collection4} alt="henna7" className="w-full rounded-md" />
          <img src={Collection3} alt="henna8" className="w-full rounded-md" />
          <img src={Collection2} alt="henna9" className="w-full rounded-md" />
          <img src={headerImage} alt="henna10" className="w-full rounded-md" />
        </div>
      </div>
    </div>
  );
};

export default Photos;
