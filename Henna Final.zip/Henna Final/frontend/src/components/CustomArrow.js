import React, { useEffect, useState } from 'react';

const CustomArrow = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const moveCursor = (e) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', moveCursor);
    return () => window.removeEventListener('mousemove', moveCursor);
  }, []);

  return (
    <div
      className="pointer-events-none fixed z-[9999] w-6 h-6 rounded-full bg-beige"
      style={{
        top: position.y - 12,
        left: position.x - 12,
        transition: 'transform 0.1s linear',
      }}
    />
  );
};

export default CustomArrow;
