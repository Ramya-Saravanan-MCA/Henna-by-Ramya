import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AiOutlineEye, AiOutlineEyeInvisible } from 'react-icons/ai';

const LoginSignup = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotPopup, setShowForgotPopup] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [forgotError, setForgotError] = useState('');

  const navigate = useNavigate();

  const validate = () => {
    let newErrors = {};

    if (!form.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!form.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (
      !/(?=.*[a-z])/.test(form.password) ||
      !/(?=.*[A-Z])/.test(form.password) ||
      !/(?=.*[!@#$%^&*])/.test(form.password) ||
      form.password.length < 6
    ) {
      newErrors.password = 'Password must have uppercase, lowercase, special char, and be at least 6 characters';
    }

    if (!isLogin && !form.name.trim()) {
      newErrors.name = 'Name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    const endpoint = isLogin ? '/api/login' : '/api/signup';

    try {
      const response = await fetch(`http://localhost:5000${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (data.message === 'Login successful') {
        setMessage('Login successful. Redirecting...');
        
        setTimeout(() => navigate('/'), 1000);
      } else if (data.message === 'User not found') {
        setMessage("Account doesn’t exist. Please sign up.");
        setIsLogin(false);
      } else if (data.message === 'Signup successful') {
        setMessage("Signup successful. Please login.");
        setIsLogin(true);
      } else {
        setMessage(data.message);
      }
    } catch {
      setMessage('Something went wrong. Please try again.');
    }
  };

  const handleForgotPassword = async () => {
    if (!forgotEmail || !newPassword) {
      setForgotError('Please fill all fields.');
      return;
    }

    if (
      !/(?=.*[a-z])/.test(newPassword) ||
      !/(?=.*[A-Z])/.test(newPassword) ||
      !/(?=.*[!@#$%^&*])/.test(newPassword) ||
      newPassword.length < 6
    ) {
      setForgotError('Weak password. Try again.');
      return;
    }

    try {
      const res = await fetch('http://localhost:5000/api/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail, newPassword }),
      });
      const result = await res.json();
      setForgotError(result.message);
      if (result.success) {
        setShowForgotPopup(false);
        setMessage('Password updated. Please login.');
      }
    } catch {
      setForgotError('Error occurred. Try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white text-gray-800 font-poppins relative">
      <form onSubmit={handleSubmit} className="bg-white p-8 shadow-lg rounded-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-4">{isLogin ? 'Login' : 'Sign Up'}</h2>

        {!isLogin && (
          <>
            <input
              type="text"
              name="name"
              placeholder="Name"
              value={form.name}
              onChange={handleChange}
              className="w-full mb-1 px-4 py-2 border rounded"
            />
            {errors.name && <p className="text-red-500 text-sm mb-3">{errors.name}</p>}
          </>
        )}

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          className="w-full mb-1 px-4 py-2 border rounded"
        />
        {errors.email && <p className="text-red-500 text-sm mb-3">{errors.email}</p>}

        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            className="w-full mb-1 px-4 py-2 border rounded pr-10"
          />
          <div
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-2.5 text-gray-500 cursor-pointer"
          >
            {showPassword ? <AiOutlineEyeInvisible size={20} /> : <AiOutlineEye size={20} />}
          </div>
        </div>
        {errors.password && <p className="text-red-500 text-sm mb-3">{errors.password}</p>}

        {isLogin && (
          <p
            className="text-sm text-blue-600 cursor-pointer mt-1 mb-2 text-right"
            onClick={() => setShowForgotPopup(true)}
          >
            Forgot Password?
          </p>
        )}

        <button type="submit" className="bg-plum text-white px-4 py-2 rounded w-full">
          {isLogin ? 'Login' : 'Sign Up'}
        </button>

        {message && <p className="mt-4 text-sm text-center text-red-600">{message}</p>}

        <p className="mt-4 text-sm text-center">
          {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
          <span className="text-plum font-semibold cursor-pointer" onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? 'Sign up' : 'Login'}
          </span>
        </p>
      </form>

      {/* Forgot Password Popup */}
      {showForgotPopup && (
        <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-sm">
            <h3 className="text-lg font-semibold mb-3">Reset Password</h3>
            <input
              type="email"
              placeholder="Enter your registered email"
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
              className="w-full mb-2 px-4 py-2 border rounded"
            />
            <input
              type="password"
              placeholder="Enter new password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full mb-2 px-4 py-2 border rounded"
            />
            {forgotError && <p className="text-red-500 text-sm mb-2">{forgotError}</p>}
            <div className="flex justify-between">
              <button onClick={handleForgotPassword} className="bg-green-600 text-white px-3 py-1 rounded">
                Update
              </button>
              <button onClick={() => setShowForgotPopup(false)} className="text-gray-600 text-sm">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginSignup;
