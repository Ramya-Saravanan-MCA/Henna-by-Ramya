import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Packages = () => {
  const navigate = useNavigate();

  const packages = [
    {
      name: 'Elegant Bridal',
      includes: 'Hands till elbow, feet till ankle',
      price: '₹3000',
      tag: 'Best for Simplicity',
    },
    {
      name: 'Premium Glow',
      includes: 'Full hands & feet + glitter work',
      price: '₹4500',
      tag: 'Most Popular',
    },
    {
      name: 'Royal Signature',
      includes: 'Full body + trial + custom design',
      price: '₹6500+',
      tag: 'Luxury Experience',
    },
  ];

  const handleChoose = (pkg) => {
    navigate('/booking', { state: { selectedPackage: pkg } });
  };

  return (
    <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4 py-10">
      {packages.map((pkg, i) => (
        <motion.div
          key={i}
          className="bg-white p-8 rounded-2xl shadow-xl border border-warmTaupe/20 relative"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: i * 0.1 }}
          viewport={{ once: false, amount: 0.3 }}
        >
          <span className="absolute top-4 right-4 bg-warmTaupe text-white text-xs font-semibold px-3 py-1 rounded-full shadow">
            {pkg.tag}
          </span>
          <h4 className="text-2xl font-bold text-warmTaupe mb-2">{pkg.name}</h4>
          <p className="text-gray-700">{pkg.includes}</p>
          <p className="mt-4 text-xl font-bold text-gray-900">{pkg.price}</p>
          <button
            onClick={() => handleChoose(pkg)}
            className="block w-full mt-6 bg-warmTaupe text-white text-center py-2 rounded-full hover:bg-plum transition font-medium"
          >
            Choose Package
          </button>
        </motion.div>
      ))}
    </div>
  );
};

export default Packages;
