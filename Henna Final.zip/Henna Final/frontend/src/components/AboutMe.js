import React from 'react';
import headerImage from '../assets/ProfileImage.png';
import Navbar from './Navbar';
import Footer from './Footer';

const AboutMe = () => {
  return (
    <div className="bg-[#FAF9F7] min-h-screen text-gray-800 flex flex-col">
      <Navbar />

      <div className="relative w-full h-[70vh] overflow-hidden">
        <img
          src={headerImage}
          alt="Ramya Saravanan"
          className="w-full h-full object-cover object-top grayscale brightness-90"
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-4xl md:text-5xl font-serif text-white font-semibold">Ramya Saravanan</h1>
          <p className="text-white uppercase tracking-widest mt-2 text-sm">Henna Artist</p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 md:px-0 py-16">
        <h2 className="text-2xl font-serif font-semibold mb-6 border-b border-gray-300 pb-2">About Me</h2>
        <p className="text-lg leading-relaxed text-gray-700 mb-6">
          I'm a passionate henna artist with over 10 years of experience transforming traditions into beautiful expressions. From a little girl experimenting with cones at family functions to a full-time artist shaping stories onto skin — this journey has been both personal and profound.
        </p>
        <p className="text-lg leading-relaxed text-gray-700 mb-6">
          Today, “Henna by Ramya” reflects more than skill — it's an emotional commitment to every bride, every pattern, and every detail. I specialize in bridal henna, custom designs, and themed artistry tailored to your story and style.
        </p>

        <blockquote className="border-l-4 border-warmTaupe pl-4 italic text-gray-600 text-base mt-10">
          “I believe henna is more than art — it's emotion, memory, and celebration. Each stroke I draw is a blend of tradition and innovation.”
          <p className="text-right mt-2 font-semibold text-warmTaupe">– Ramya Saravanan</p>
        </blockquote>
      </div>

      <div className="text-center py-12 bg-[#F5F3F0]">
        <h3 className="text-xl md:text-2xl font-serif mb-4">Looking for timeless bridal henna?</h3>
        <a
          href="/bookings"
          className="inline-block px-6 py-3 bg-warmTaupe text-white rounded-full hover:bg-plum transition font-medium"
        >
          Book Your Date
        </a>
      </div>

      <Footer />
    </div>
  );
};

export default AboutMe;
