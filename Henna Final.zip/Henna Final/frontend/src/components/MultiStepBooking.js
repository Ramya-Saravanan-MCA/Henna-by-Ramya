import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from './Navbar';
import Footer from './Footer';
import bridalHero from '../assets/hero.png';
import CustomArrow from './CustomArrow';

const StepIndicator = ({ currentStep }) => {
  const steps = ['Signup', 'Login', 'Booking Form', 'Thank You'];
  return (
    <div className="flex justify-center gap-6 mb-8">
      {steps.map((step, index) => (
        <div key={index} className="flex flex-col items-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: currentStep === index ? 1.1 : 1 }}
            transition={{ duration: 0.3 }}
            className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white transition-all duration-300 ${
              currentStep === index ? 'bg-warmTaupe shadow-lg' : 'bg-gray-300'
            }`}
          >
            {index + 1}
          </motion.div>
          <span className={`text-sm mt-1 ${currentStep === index ? 'text-warmTaupe font-medium' : 'text-gray-500'}`}>
            {step}
          </span>
        </div>
      ))}
    </div>
  );
};

const MultiStepBooking = () => {
  const [step, setStep] = useState(0);
  const [showThankYou, setShowThankYou] = useState(false);
  const [errorPopup, setErrorPopup] = useState('');
  const [showResetPopup, setShowResetPopup] = useState(false);
  
  const navigate = useNavigate();


const validateSignupField = (field, value) => {
  let error = '';
  if (field === 'name' && !value) error = 'Full name is required';
  if (field === 'email' && (!value || !validateEmail(value))) error = 'Valid email is required';
  if (field === 'phone' && (!value || !validatePhone(value))) error = 'Valid 10-digit phone number required';
  if (field === 'address' && !value) error = 'Address is required';
  if (field === 'password' && (!value || !validatePassword(value)))
    error = 'Min 8 chars, 1 uppercase & 1 number required';

  setSignupErrors((prev) => {
    const updated = { ...prev };
    if (error) updated[field] = error;
    else delete updated[field];
    return updated;
  });
};

const validateLoginField = (field, value) => {
  let error = '';
  if (field === 'email' && (!value || !validateEmail(value))) error = 'Valid email is required';
  if (field === 'password' && !value) error = 'Password is required';

  setLoginErrors((prev) => {
    const updated = { ...prev };
    if (error) updated[field] = error;
    else delete updated[field];
    return updated;
  });
};

const validateBookingField = (field, value) => {
  let error = '';
  if (field === 'date') {
    if (!value) error = 'Date is required';
    else if (new Date(value).setHours(0, 0, 0, 0) < new Date().setHours(0, 0, 0, 0)) {
      error = 'Select a future date';
    }
  }
  if (field === 'time' && !value) error = 'Time is required';
  if (field === 'serviceType' && !value) error = 'Service type is required';
  if (field === 'location' && !value) error = 'Location is required';
  if (field === 'design' && value) {
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
    if (!validTypes.includes(value.type)) error = 'Only image files are allowed';
  }

  setBookingErrors((prev) => {
    const updated = { ...prev };
    if (error) updated[field] = error;
    else delete updated[field];
    return updated;
  });
};


  const [signupData, setSignupData] = useState({ name: '', email: '', phone: '', address: '', password: '' });
  const [signupErrors, setSignupErrors] = useState({});

  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [loginErrors, setLoginErrors] = useState({});

  const [resetData, setResetData] = useState({ email: '', newPassword: '', confirmPassword: '' });
  const [resetErrors, setResetErrors] = useState({});

  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    serviceType: 'bridal',
    location: '',
    notes: '',
    design: null
  });
  const [bookingErrors, setBookingErrors] = useState({});

  useEffect(() => {
    if (errorPopup) {
      const timer = setTimeout(() => setErrorPopup(''), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorPopup]);

  const validateEmail = (email) => /\S+@\S+\.\S+/.test(email);
  const validatePhone = (phone) => /^\d{10}$/.test(phone);
  const validatePassword = (password) => /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/.test(password);

  const handleSignup = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(signupData),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.message === 'Email already exists') {
          setErrorPopup(
            <span>
              User already exists.{' '}
              <button onClick={() => setStep(1)} className="underline font-medium">
                Login here
              </button>
            </span>
          );
        } else {
          setErrorPopup(result.message || 'Signup failed');
        }
        return;
      }

      setErrorPopup('');
      setStep(1);
    } catch (error) {
      console.error('Signup error:', error);
      setErrorPopup('Signup request failed');
    }
  };

  const handleLogin = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      });

      const result = await response.json();

      if (!response.ok) {
        setErrorPopup(result.message || 'Login failed');
        return;
      }

      setErrorPopup('');
      setStep(2);
    } catch (error) {
      console.error('Login error:', error);
      setErrorPopup('Login request failed');
    }
  };

 const handleResetPassword = async () => {
  const { email, newPassword, confirmPassword } = resetData;

  const errors = {};

  if (!validateEmail(email)) errors.email = 'Valid email required';
  if (!validatePassword(newPassword)) {
    errors.newPassword = 'Password must be 8+ chars, 1 uppercase, 1 number';
  }
  if (newPassword !== confirmPassword) {
    errors.confirmPassword = 'Passwords do not match';
  }

  if (Object.keys(errors).length > 0) {
    setResetErrors(errors);
    return;
  }

  try {
    const res = await fetch('http://localhost:5000/api/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password: newPassword }),
    });

    const result = await res.json();

    if (!res.ok) return setResetErrors({ email: result.message });

    // ✅ Show success popup and go to login after 2 seconds
    setErrorPopup('Password updated successfully');
    setShowResetPopup(false);
    setResetData({ email: '', newPassword: '', confirmPassword: '' });
    setResetErrors({});

    setTimeout(() => {
      setErrorPopup('');
      setStep(1); // Go to login step
    }, 2000);
  } catch (err) {
    console.error('Reset error:', err);
    setResetErrors({ email: 'Reset failed, try again' });
  }
};

const handleBooking = async (e) => {
  e.preventDefault();

  // Optional: Validate required fields before submission
  const errors = {};
  if (!bookingData.date) errors.date = 'Date is required';
  if (!bookingData.serviceType) errors.serviceType = 'Service type is required';
  if (!bookingData.location) errors.location = 'Location is required';

  if (Object.keys(errors).length > 0) {
    setBookingErrors(errors);
    return;
  }

  try {
    const response = await fetch('http://localhost:5000/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        date: bookingData.date,
        time: bookingData.time,
        serviceType: bookingData.serviceType,
        location: bookingData.location,
        notes: bookingData.notes,
        // You can add design later if you implement image upload
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      setErrorPopup(result.error || 'Booking failed');
      return;
    }

    // Success
    setBookingErrors({});
    setStep(3);
    setTimeout(() => setShowThankYou(true), 500);
  } catch (error) {
    console.error('Booking error:', error);
    setErrorPopup('Network error. Try again.');
  }
};

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <CustomArrow />
      {errorPopup && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded shadow z-50">
          {errorPopup}
        </div>
      )}

      {showResetPopup && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm">
            <h3 className="text-xl font-semibold mb-4">Reset Password</h3>
            <input
              type="email"
              placeholder="Email"
              className="modern-input mb-2"
              value={resetData.email}
              onChange={(e) => setResetData({ ...resetData, email: e.target.value })}
            />
            {resetErrors.email && <p className="text-red-500 text-sm mb-2">{resetErrors.email}</p>}
            <input
              type="password"
              placeholder="New Password"
              className="modern-input mb-2"
              value={resetData.newPassword}
              onChange={(e) => setResetData({ ...resetData, newPassword: e.target.value })}
            />
            {resetErrors.newPassword && <p className="text-red-500 text-sm mb-2">{resetErrors.newPassword}</p>}
            <input
              type="password"
              placeholder="Confirm Password"
              className="modern-input mb-4"
              value={resetData.confirmPassword}
              onChange={(e) => setResetData({ ...resetData, confirmPassword: e.target.value })}
            />
            {resetErrors.confirmPassword && <p className="text-red-500 text-sm mb-2">{resetErrors.confirmPassword}</p>}
            <div className="flex justify-end gap-2">
              <button className="text-sm" onClick={() => setShowResetPopup(false)}>Cancel</button>
              <button className="bg-warmTaupe text-white px-4 py-1 rounded" onClick={handleResetPassword}>Update</button>
            </div>
          </div>
        </div>
      )}

      <div className="relative h-[65vh] overflow-hidden">
        <img src={bridalHero} alt="Bridal Henna" className="absolute inset-0 w-full h-full object-cover scale-105" />
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative z-10 flex items-center justify-center h-full px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <h1 className="text-4xl md:text-6xl font-cursive font-bold text-white drop-shadow">
              Personalized Henna for Your Big Day
            </h1>
            <p className="mt-4 text-lg md:text-xl text-white font-light drop-shadow">
              Crafted with tradition, love, and artistic finesse.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="mt-16 px-4 md:px-16 mb-20 flex-grow">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row rounded-3xl overflow-hidden shadow-xl bg-white border"
        >
          
          <div className="w-full md:w-1/2 p-10 flex flex-col justify-center">
            <motion.img
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              src={bridalHero}
              alt="Henna"
              className="rounded-2xl shadow mb-6"
            />
            <h2 className="text-3xl font-semibold text-plum mb-2">Perfect Bridal Experience</h2>
            <p className="text-slate-600 text-lg">
              Discover elegance in every stroke. Book your bridal henna with confidence and tradition.
            </p>
          </div>

          <div className="w-full md:w-1/2 bg-white p-10">
            <StepIndicator currentStep={step} />

            {step === 0 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-center text-gray-800">Signup</h2>
                {['name', 'email', 'phone', 'address', 'password'].map((field) => (
                  <div key={field}>
                    <input
                      type={field === 'password' ? 'password' : 'text'}
                      placeholder={field === 'name' ? 'Full Name' : field.charAt(0).toUpperCase() + field.slice(1)}
                      className="modern-input"
                      value={signupData[field]}
                      onChange={(e) => setSignupData({ ...signupData, [field]: e.target.value })}
                      onBlur={(e) => validateSignupField(field, e.target.value)}
                    />
                    {signupErrors[field] && <p className="text-red-500 text-sm mt-1">{signupErrors[field]}</p>}
                  </div>
                ))}
                <button
                  onClick={handleSignup}
                  className="w-full bg-warmTaupe text-white py-3 rounded-lg font-medium hover:bg-[#a76f50] transition"
                >
                  Next
                </button>
              </div>
            )}

            {step === 1 && (
            <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-center text-gray-800">Login</h2>
            {['email', 'password'].map((field) => (
                <div key={field}>
                  <input
                    type={field === 'password' ? 'password' : 'email'}
                    placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                    className="modern-input"
                    value={loginData[field]}
                    onChange={(e) => setLoginData({ ...loginData, [field]: e.target.value })}
                    onBlur={(e) => validateLoginField(field, e.target.value)}
                  />
                  {loginErrors[field] && <p className="text-red-500 text-sm mt-1">{loginErrors[field]}</p>}
                </div>
              ))}
              <button
                onClick={handleLogin}
                className="w-full bg-warmTaupe text-white py-3 rounded-lg font-medium hover:bg-[#a76f50] transition"
              >
                Login
              </button>
              
              <p className="text-sm text-center mt-2">
                <button
                  onClick={() => setShowResetPopup(true)}
                  className="w-full bg-warmTaupe text-white py-3 rounded-lg font-medium hover:bg-[#a76f50] transition"
                >
                  Forgot Password?
                </button>
              </p>
            </div>
          )}


            {step === 2 && (
              <form onSubmit={handleBooking} className="space-y-6">
                <h2 className="text-2xl font-semibold text-center text-gray-800">Booking Form</h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Date</label>
                  <input
                    type="date"
                    className="modern-input"
                    value={bookingData.date}
                    onChange={(e) => setBookingData({ ...bookingData, date: e.target.value })}
                    onBlur={(e) => validateBookingField('date', e.target.value)}
                  />
                  {bookingErrors.date && <p className="text-red-500 text-sm mt-1">{bookingErrors.date}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Service Type</label>
                  <select
                    className="modern-input"
                    value={bookingData.serviceType}
                    onChange={(e) => setBookingData({ ...bookingData, serviceType: e.target.value })}
                    onBlur={(e) => validateBookingField('serviceType', e.target.value)}
                  >
                    <option value="bridal">Bridal</option>
                    <option value="mandala">Mandala</option>
                    <option value="simple">Simple</option>
                    <option value="feet">Feet</option>
                  </select>
                  {bookingErrors.serviceType && <p className="text-red-500 text-sm mt-1">{bookingErrors.serviceType}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Location with landmark</label>
                  <input
                    type="text"
                    className="modern-input"
                    value={bookingData.location}
                    onChange={(e) => setBookingData({ ...bookingData, location: e.target.value })}
                    onBlur={(e) => validateBookingField('location', e.target.value)}
                  />
                  {bookingErrors.location && <p className="text-red-500 text-sm mt-1">{bookingErrors.location}</p>}
                </div>

                <div className="flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="bg-gray-200 px-6 py-2 rounded hover:bg-gray-300"
                  >
                    Back
                  </button>
                  <button type="submit" className="bg-warmTaupe text-white px-6 py-2 rounded hover:bg-[#a76f50]">
                    Submit
                  </button>
                </div>
              </form>
            )}

            {step === 3 && showThankYou && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center space-y-4">
                <h3 className="text-3xl font-bold text-green-600">Thank You!</h3>
                <p className="text-gray-700">Your booking has been successfully submitted.</p>
                <button
                  onClick={() => navigate('/')}
                  className="bg-warmTaupe text-white px-6 py-3 rounded-lg hover:bg-[#a76f50] transition"
                >
                  Go Home
                </button>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
};

export default MultiStepBooking;
