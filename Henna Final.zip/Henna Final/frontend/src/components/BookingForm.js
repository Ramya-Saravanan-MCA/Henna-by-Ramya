import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { jsPDF } from 'jspdf';
import Footer from './Footer';
import bridalHero from '../assets/hero.png';
import CustomArrow from './CustomArrow';

const BookingForm = ({ user }) => {
  const [formData, setFormData] = useState({
    
    name: '',
    email: '',
    phone: '',
    date: '',
    serviceType: '',
    location: '',
    notes: '',
    hennaId: '',
  });
  useEffect(() => {
    if (user?.email) {
      fetch(`http://localhost:5000/api/login/getUser/${user.email}`)
        .then((res) => res.json())
        .then((data) => {
          setFormData((prev) => ({
            ...prev,
            name: data.name || '',
            email: data.email || '',
          }));
        })
        .catch((err) => console.error('User fetch failed', err));
    }
  }, [user]);
  
  

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [successPopup, setSuccessPopup] = useState('');
  const [errorPopup, setErrorPopup] = useState('');
  const [receiptData, setReceiptData] = useState(null); 
  const [loginCheckError, setLoginCheckError] = useState('');


  useEffect(() => {
    if (successPopup || errorPopup) {
      const timer = setTimeout(() => {
        setSuccessPopup('');
        setErrorPopup('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [successPopup, errorPopup]);

  const generateHennaId = () => {
    return 'HN-' + Math.random().toString(36).substr(2, 8).toUpperCase();
  };

  const validate = (values = formData) => {
    const newErrors = {};
    if (!values.name.trim()) newErrors.name = 'Name is required';
    if (!values.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!values.phone.trim()) {
      newErrors.phone = 'Phone is required';
    } else if (!/^\d{10}$/.test(values.phone)) {
      newErrors.phone = 'Enter a valid 10-digit phone number';
    }
    if (!values.date.trim()) newErrors.date = 'Date is required';
    if (!values.serviceType.trim()) newErrors.serviceType = 'Select a service type';
    if (!values.location.trim()) newErrors.location = 'Location is required';
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedForm = { ...formData, [name]: value };
    setFormData(updatedForm);

    if (touched[name]) {
      const updatedErrors = validate(updatedForm);
      setErrors((prev) => ({ ...prev, [name]: updatedErrors[name] }));
    }
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const fieldErrors = validate(formData);
    setErrors((prev) => ({ ...prev, [name]: fieldErrors[name] }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const res = await fetch('http://localhost:5000/api/check-login-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: formData.email }),
      });
      const data = await res.json();
      if (!data.exists) {
        setLoginCheckError('Email is not registered. Please Signup first');
        return;
      } else {
        setLoginCheckError('');
      }
      
    } catch (err) {
      setErrorPopup('Could not verify email. Please try again.');
      return;
    }
  
    const finalErrors = validate();
    setErrors(finalErrors);
    setTouched({
      name: true,
      email: true,
      phone: true,
      date: true,
      serviceType: true,
      location: true,
    });
  
    if (Object.keys(finalErrors).length > 0) return;
  
    const hennaId = generateHennaId();
    const fullData = { ...formData, hennaId };
    
    try {
      const response = await fetch('http://localhost:5000/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fullData),
      });
  
      const result = await response.json();
  
      if (response.ok) {
        setSuccessPopup(`Booking submitted successfully! Your Henna ID: ${hennaId}`);
        setReceiptData(fullData);
        setFormData({
          name: '',
          email: '',
          phone: '',
          date: '',
          serviceType: '',
          location: '',
          notes: '',
          hennaId: '',
        });
        setErrors({});
        setTouched({});
      } else {
        setErrorPopup(result.message || 'Booking failed. Try again.');
      }
    } catch (error) {
      console.error('Booking error:', error);
      setErrorPopup('Server error. Please try again later.');
    }
  };
  

  const handleDownloadReceipt = () => {
    if (!receiptData) return;
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Henna by Ramya - Booking Receipt', 20, 20);
    doc.setFontSize(12);
    doc.text(`Name: ${receiptData.name}`, 20, 40);
    doc.text(`Email: ${receiptData.email}`, 20, 50);
    doc.text(`Phone: ${receiptData.phone}`, 20, 60);
    doc.text(`Date: ${receiptData.date}`, 20, 70);
    doc.text(`Service Type: ${receiptData.serviceType}`, 20, 80);
    doc.text(`Location: ${receiptData.location}`, 20, 90);
    doc.text(`Notes: ${receiptData.notes || '-'}`, 20, 100);
    doc.text(`Henna ID: ${receiptData.hennaId}`, 20, 110);
    doc.save(`Henna_Receipt_${receiptData.hennaId}.pdf`);
  
    setReceiptData(null);
  };
  
  console.log("Logged-in user:", user);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <CustomArrow />

      {errorPopup && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-4 py-2 rounded shadow z-50">
          {errorPopup}
        </div>
      )}
      {successPopup && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded shadow z-50">
          {successPopup}
        </div>
      )}

      <div className="relative h-[60vh] overflow-hidden">
        <img src={bridalHero} alt="Bridal Banner" className="absolute inset-0 w-full h-full object-cover scale-105" />
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 flex items-center justify-center h-full px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <h1 className="text-4xl md:text-6xl font-cursive font-bold text-white drop-shadow">
              Book Your Henna Experience
            </h1>
            <p className="mt-4 text-lg md:text-xl text-white font-light drop-shadow">
              Timeless beauty, just a form away.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="mt-16 px-4 md:px-16 mb-20 flex-grow">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row rounded-3xl overflow-hidden shadow-xl bg-white border"
        >
          <div className="w-full md:w-1/2 p-10 flex flex-col justify-center bg-white">
            <motion.img
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              src={bridalHero}
              alt="Henna Preview"
              className="rounded-2xl shadow mb-6"
            />
            <h2 className="text-3xl font-semibold text-plum mb-2">Cherish Your Moments</h2>
            <p className="text-slate-600 text-lg">
              Book now to make your event colorful and elegant with premium henna art.
            </p>

            {receiptData && (
              <button
                onClick={handleDownloadReceipt}
                className="mt-6 bg-emerald-600 text-white py-3 rounded-lg font-medium hover:bg-emerald-700 transition"
              >
                Download Receipt
              </button>
            )}
          </div>

          <div className="w-full md:w-1/2 bg-white p-10">
            <form onSubmit={handleSubmit} className="space-y-6">
              <h2 className="text-2xl font-semibold text-center text-gray-800 mb-4">Booking Form</h2>

              {['name', 'phone', 'date', 'location'].map((field) => (
                <div key={field}>
                  <input
                    type={field === 'date' ? 'date' : 'text'}
                    name={field}
                    placeholder={field === 'name'
                                    ? 'Full Name'
                                    : field.charAt(0).toUpperCase() + field.slice(1)}
                    className="modern-input"
                    value={formData[field]}
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />
                  {touched[field] && errors[field] && (
                    <p className="text-red-500 text-sm mt-1">{errors[field]}</p>
                  )}
                </div>
              ))}

              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  className="modern-input"
                  value={formData.email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                />
                {touched.email && errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                )}
                {loginCheckError && (
                  <p className="text-red-500 text-sm mt-1">{loginCheckError}</p>
                )}
              </div>


              <div>
                <select
                  name="serviceType"
                  value={formData.serviceType}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className="modern-input"
                >
                  <option value="">Select Service Type</option>
                  <option value="bridal">Bridal</option>
                  <option value="mandala">Mandala</option>
                  <option value="simple">Simple</option>
                  <option value="feet">Feet</option>
                </select>
                {touched.serviceType && errors.serviceType && (
                  <p className="text-red-500 text-sm mt-1">{errors.serviceType}</p>
                )}
              </div>

              <textarea
                name="notes"
                placeholder="Notes (optional)"
                className="modern-input"
                rows={3}
                value={formData.notes}
                onChange={handleChange}
              />

              <button
                type="submit"
                className="w-full bg-plum text-white py-3 rounded-lg font-medium hover:bg-opacity-90 transition"
              >
                Submit Booking
              </button>
            </form>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
};

export default BookingForm;
