/* eslint-disable no-undef */
import React from 'react'
import { FaHandPointDown } from "react-icons/fa";
import { motion } from 'framer-motion';
import { SlideLeft } from '../utility/animation';

const WhyChooseData = [
  {
    id: 1,
    title: "Personalized Bridal Henna Care",
    desc: "Dedicated one-on-one henna sessions tailored to your personal style, ensuring every bride feels special and confident on her big day",
    link: "/",
    icon: <FaHandPointDown />,
    bgColor: "#F5ECE4",
    delay: 0.3,
  },
  {
    id: 2,
    title: "Trusted by Happy Clients",
    desc: "With over 100 delighted clients and glowing reviews, we take pride in delivering memorable henna experiences that exceed expectations",
    link: "/",
    icon: <FaHandPointDown />,
    bgColor: "#F5ECE4",
    delay: 0.3,
  },
  {
    id: 3,
    title: "Safe Organic Henna Stains",
    desc: "We use only 100% organic, chemical-free henna that’s safe for all skin types, giving you deep, rich stains without compromising on health",
    link: "/",
    icon: <FaHandPointDown />,
    bgColor: "#F5ECE4",
    delay: 0.3,
  },
  {
    id: 4,
    title: "Creative Elegant Design Touch",
    desc: "Each design is handcrafted with passion and precision, blending traditional elegance with modern aesthetics to reflect your personality",
    link: "/",
    icon: <FaHandPointDown />,
    bgColor: "#F5ECE4",
    delay: 0.3,
  },
]

const WhyChoose = () => {
  return (
    <div>
      <div className='container py-24'>
        <div className='space-y-4 p-6 text-center max-w-[500px] mx-auto mb-5'>
            <h1 className='uppercase font-semibold text-warmTaupe'>Why Choose Us</h1>
            <p className='font-semibold text-3xl'>Benefits of our Services</p>
        </div>
        <div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6'>
          {
            WhyChooseData.map((item) => {
              return(
                <motion.div
                variants={SlideLeft(item.delay)}
                initial="hidden"
                whileInView={"visible"}
                 className='space-y-4 p-6 rounded-xl shadow-[0_0_22px_rgba(0,0,0,0.15)]'>
                  <div style={{backgroundColor: item.bgColor}} className='w-10 h-10 rounded-lg flex justify-center items-center text-plum'>
                    <div className='text-2xl'>{item.icon}</div>
                  </div>
                  <p className='font-semibold'>{item.title}</p>
                  <p className='text-sm text-gray-500'>{item.desc}</p>
                </motion.div>
              )
            })
          }
        </div>
      </div>
    </div>
  )
}

export default WhyChoose