export const NavbarMenu = [
    {
        id:1,
        title:"HOME",
        link:"/"
    },
    {
        id: 2,
        title: "SERVICES",
        link: "/services",
    },
    {
        id:3,
        title:"BOOKINGS",
        link:"/bookings"
    },
    {
        id:4,
        title:"CONTACT US",
        link:"/contact"
    },
]