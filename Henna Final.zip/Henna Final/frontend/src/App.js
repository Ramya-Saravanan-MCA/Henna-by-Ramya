import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Home from './components/Home';
import BridalService from './components/BridalService';
import ContactPage from './components/ContactPage';
import Photos from './components/Photos';
import AboutMe from './components/AboutMe';
import BookingForm from './components/BookingForm';
import LoginSignup from './components/LoginSignup';
import Navbar from './components/Navbar';
import AdminPanel from './admin/AdminApp';

const AppContent = ({ user, setUser }) => {
  const location = useLocation();

  // Hide Navbar on both admin and login/signup routes
  const hideNavbar = location.pathname.startsWith('/admin') || location.pathname === '/auth';

  return (
    <>
      {!hideNavbar && <Navbar user={user} setUser={setUser} />}
      <main className="overflow-x-hidden">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<BridalService />} />
          <Route path="/bookings" element={<BookingForm user={user} />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/gallery" element={<Photos />} />
          <Route path="/about" element={<AboutMe />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/auth" element={<LoginSignup setUser={setUser} />} />
        </Routes>
      </main>
    </>
  );
};


const App = () => {
  const [user, setUser] = useState(null);

  return (
    <Router>
      <AppContent user={user} setUser={setUser} />
    </Router>
  );
};

export default App;
